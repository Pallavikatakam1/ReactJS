import { useState, useEffect } from "react"
import './App.css'
import DataEntry from './DataEntry.jsx'
import Table from './Table.jsx'
import Router from './Router.jsx'
function App() {

  return (
    <>
      <RouterFile />
    </>
  )
}

export default App
